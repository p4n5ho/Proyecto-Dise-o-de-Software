/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import Dominio.Asignacion;
import Dominio.ElementoQuimico;
import Dominio.EmpresaProductora;
import Dominio.EmpresaTransporte;
import Dominio.Residuo;
import Dominio.Solicitud;
import Dominio.Traslado;
import Dominio.Usuario;
import Dominio.Vehiculo;
import Excepciones.ResiduosException;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Alejandro Galindo
 */
public class facadeDatosTest {
    
    public facadeDatosTest() {
    }

    /**
     * Test of facadeDatos method, of class facadeDatos.
     */
    @Test
    public void testFacadeDatos() {
        IFacadeDatos instance = FabricaDatos.getFachada();
        if(instance == null){
            fail("La Fabrica no fabrica");
        }
    }

    /**
     * Test of agregarResiduo method, of class facadeDatos.
     */
    @Test
    public void testAgregarResiduo() {
        IFacadeDatos instance = FabricaDatos.getFachada();
        List<ElementoQuimico> lista = instance.getListaElementosQuimicos();
        List<ElementoQuimico> listaFinal = new ArrayList<>();
        
        listaFinal.add(lista.get(13));
        listaFinal.add(lista.get(20));
        listaFinal.add(lista.get(30));
        
        Residuo residuo = new Residuo("123987", "Residuo de prueba", (ArrayList<ElementoQuimico>) listaFinal);
        
        try {
            instance.agregarResiduo(residuo);
        } catch (ResiduosException residuosException) {
            fail("No se pudo agregar el residuo porque esta repetido");
        }
        
        try {
            instance.agregarResiduo(residuo);
            fail("No se pudo agregar porque esta repetido");
        } catch (ResiduosException residuosException) {
        }
    }

    /**
     * Test of obtenerResiduo method, of class facadeDatos.
     */
    @Test
    public void testObtenerResiduo() {
        IFacadeDatos instance = FabricaDatos.getFachada();
        Residuo residuo = instance.obtenerResiduo("124325");
        if(residuo == null){
            fail("El residuo si existe");
        }
    }

    /**
     * Test of agregarSolicitudTraslado method, of class facadeDatos.
     */
    @Test
    public void testAgregarSolicitudTraslado() {
        IFacadeDatos instance = FabricaDatos.getFachada();
        Solicitud solicitud = new Solicitud(0, "2019-07-05", "SMT040178IND", false);
        try {
            instance.agregarSolicitudTraslado(solicitud);
        } catch (ResiduosException residuosException) {
            fail("Debe agregarse la solicitud");
        }
    }

    /**
     * Test of obtenerEmpresaProductora method, of class facadeDatos.
     */
    @Test
    public void testObtenerEmpresaProductora() {
        IFacadeDatos instance = FabricaDatos.getFachada();
        EmpresaProductora empresa = instance.obtenerEmpresaProductora("ACX061699COM");
        if(empresa == null){
            fail("Si existe la empresa");
        }
    }

    /**
     * Test of obtenerEmpresaTransporte method, of class facadeDatos.
     */
    @Test
    public void testObtenerEmpresaTransporte() {
        IFacadeDatos instance = FabricaDatos.getFachada();
        EmpresaTransporte empresa = instance.obtenerEmpresaTransporte("RDE041888IND");
        if(empresa == null){
            fail("Si existe la empresa");
        }
    }

    /**
     * Test of getListaResiduos method, of class facadeDatos.
     */
    @Test
    public void testGetListaResiduos() {
        IFacadeDatos instance = FabricaDatos.getFachada();
        try {
            List<Residuo> residuos = instance.getListaResiduos();
            
            if (residuos == null) {
                fail("La lista no es nula");
            } else if (residuos.isEmpty()) {
                fail("La lista no debe estar vacia");
            }
        } catch (ResiduosException residuosException) {
            fail("Error inesperado");
        }
    }

    /**
     * Test of getListaTraslados method, of class facadeDatos.
     */
    @Test
    public void testGetListaTraslados() {
        IFacadeDatos instance = FabricaDatos.getFachada();
        try {
            List<Traslado> traslados = instance.getListaTraslados();
            
            if (traslados != null) {
                fail("La lista es nula");
            }
        } catch (ResiduosException residuosException) {
            fail("Error inesperado");
        }
    }

    /**
     * Test of getListaElementosQuimicos method, of class facadeDatos.
     */
    @Test
    public void testGetListaElementosQuimicos() {
        IFacadeDatos instance = FabricaDatos.getFachada();
        try {
            List<ElementoQuimico> elementos = instance.getListaElementosQuimicos();
            
            if (elementos == null) {
                fail("La lista no es nula");
            } else if (elementos.isEmpty()) {
                fail("La lista no debe estar vacia");
            }
        } catch (ResiduosException residuosException) {
            fail("Error inesperado");
        }
    }

    /**
     * Test of getListaEmpresasProductoras method, of class facadeDatos.
     */
    @Test
    public void testGetListaEmpresasProductoras() {
        IFacadeDatos instance = FabricaDatos.getFachada();
        try {
            List<EmpresaProductora> empresas = instance.getListaEmpresasProductoras();
            
            if (empresas == null) {
                fail("La lista no es nula");
            } else if (empresas.isEmpty()) {
                fail("La lista no debe estar vacia");
            }
        } catch (ResiduosException residuosException) {
            fail("Error inesperado");
        }
    }

    /**
     * Test of getListaEmpresasTransportes method, of class facadeDatos.
     */
    @Test
    public void testGetListaEmpresasTransportes() {
        IFacadeDatos instance = FabricaDatos.getFachada();
        try {
            List<EmpresaTransporte> empresas = instance.getListaEmpresasTransportes();
            
            if (empresas == null) {
                fail("La lista no es nula");
            } else if (empresas.isEmpty()) {
                fail("La lista no debe estar vacia");
            }
        } catch (ResiduosException residuosException) {
            fail("Error inesperado");
        }
    }

    /**
     * Test of obtenerUsuario method, of class facadeDatos.
     */
    @Test
    public void testObtenerUsuario() {
        IFacadeDatos instance = FabricaDatos.getFachada();
        Usuario usuario = instance.obtenerUsuario("SMT040178IND");
        
        if(usuario == null){
            fail("El usuario si existe");
        }
    }

    /**
     * Test of agregarUsuario method, of class facadeDatos.
     */
    @Test
    public void testAgregarUsuario() {
        IFacadeDatos instance = FabricaDatos.getFachada();
        Usuario usuario = new Usuario("TPS030799ONG", "123", 0);
        usuario.setNombre("Empresa de prueba");
        
        try {
            instance.agregarUsuario(usuario);
        } catch (ResiduosException residuosException) {
            fail("Debe agregar al usuario");
        }
        
    }

    /**
     * Test of getListaSolicitudes method, of class facadeDatos.
     */
    @Test
    public void testGetListaSolicitudes() {
        IFacadeDatos instance = FabricaDatos.getFachada();
        try {
            List<Solicitud> solicitudes = instance.getListaSolicitudes();
            
            if (solicitudes == null) {
                fail("La lista no es nula");
            } else if (solicitudes.isEmpty()) {
                fail("La lista no debe estar vacia");
            }
        } catch (ResiduosException residuosException) {
            fail("Error inesperado");
        }
    }

    /**
     * Test of asignarTraslado method, of class facadeDatos.
     */
    @Test
    public void testAsignarTraslado() {
        IFacadeDatos instance = FabricaDatos.getFachada();
        Asignacion asignacion = new Asignacion(0, 2, "RDE041888IND", "124325", 100, "KG", false);
        
        try {
            instance.asignarTraslado(asignacion);
        } catch (ResiduosException residuosException) {
            fail("Deberia asignarlo");
        }
    }

    /**
     * Test of obtenerSolicitud method, of class facadeDatos.
     */
    @Test
    public void testObtenerSolicitud() {
        IFacadeDatos instance = FabricaDatos.getFachada();
        Solicitud solicitud = instance.obtenerSolicitud("1");
        if(solicitud == null){
            fail("La solicitud si existe");
        }
    }

    /**
     * Test of getListaAsignaciones method, of class facadeDatos.
     */
    @Test
    public void testGetListaAsignaciones() {
        IFacadeDatos instance = FabricaDatos.getFachada();
        try {
            List<Asignacion> asignaciones = instance.getListaAsignaciones();
            
            if (asignaciones == null) {
                fail("La lista no es nula");
            } else if (asignaciones.isEmpty()) {
                fail("La lista no debe estar vacia");
            }
        } catch (ResiduosException residuosException) {
            fail("Error inesperado");
        }
    }

    /**
     * Test of getListaVehiculos method, of class facadeDatos.
     */
    @Test
    public void testGetListaVehiculos() {
        IFacadeDatos instance = FabricaDatos.getFachada();
        try {
            List<Vehiculo> vehiculos = instance.getListaVehiculos();
            
            if (vehiculos == null) {
                fail("La lista no es nula");
            } else if (vehiculos.isEmpty()) {
                fail("La lista no debe estar vacia");
            }
        } catch (ResiduosException residuosException) {
            fail("Error inesperado");
        }
    }

    /**
     * Test of registrarTraslado method, of class facadeDatos.
     */
    @Test
    public void testRegistrarTraslado() {
        IFacadeDatos instance = FabricaDatos.getFachada();
        List<Vehiculo> vehiculos = instance.getListaVehiculos();
        List<Vehiculo> vehiculosFinal = new ArrayList<>();
        vehiculosFinal.add(vehiculos.get(1));
        
        Traslado traslado = new Traslado(0, 2, "2019-07-05", "Pues es una prueba", vehiculosFinal, 100, "SMT040178IND", 0);
        try {
            instance.registrarTraslado(traslado);
        } catch (ResiduosException residuosException) {
            fail("Deberia agregar el traslado");
        }
    }
    
}
