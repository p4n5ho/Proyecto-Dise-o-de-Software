/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

import Dominio.Asignacion;
import Dominio.DetallesSolicitud;
import Dominio.ElementoQuimico;
import Dominio.EmpresaProductora;
import Dominio.EmpresaTransporte;
import Dominio.Residuo;
import Dominio.Solicitud;
import Dominio.Traslado;
import Dominio.Usuario;
import Dominio.Vehiculo;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Alejandro Galindo
 */
public class facadeNegocioTest {
    
    public facadeNegocioTest() {
        IFacadeNegocio instance = FabricaNegocio.getFachada();
        if(instance == null){
            fail("La fabrica no funciona");
        }
    }

    /**
     * Test of verificarSesion method, of class facadeNegocio.
     */
    @Test
    public void testVerificarSesion() {
        IFacadeNegocio instance = FabricaNegocio.getFachada();
        if (!instance.verificarSesion("LOT030298DNI", "123456", 2)) {
            fail("Debe loguear administrador");
        }
    }

    /**
     * Test of registrarUsuario method, of class facadeNegocio.
     */
    @Test
    public void testRegistrarUsuario() {
        System.out.println("registrarUsuario");
        String codigo = "";
        String password = "";
        int tipo = 0;
        String nombre = "";
        facadeNegocio instance = new facadeNegocio();
        boolean expResult = false;
        boolean result = instance.registrarUsuario(codigo, password, tipo, nombre);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of obtenerUsuarioLogueado method, of class facadeNegocio.
     */
    @Test
    public void testObtenerUsuarioLogueado() {
        System.out.println("obtenerUsuarioLogueado");
        facadeNegocio instance = new facadeNegocio();
        Usuario expResult = null;
        Usuario result = instance.obtenerUsuarioLogueado();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of agregarResiduo method, of class facadeNegocio.
     */
    @Test
    public void testAgregarResiduo() {
        System.out.println("agregarResiduo");
        String codigo = "";
        String nombre = "";
        List<ElementoQuimico> elementos = null;
        EmpresaProductora empresa = null;
        facadeNegocio instance = new facadeNegocio();
        instance.agregarResiduo(codigo, nombre, elementos, empresa);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of agregarSolicitudTraslado method, of class facadeNegocio.
     */
    @Test
    public void testAgregarSolicitudTraslado() {
        System.out.println("agregarSolicitudTraslado");
        String fecha = "";
        String IDEmpresa = "";
        List<DetallesSolicitud> detalles = null;
        facadeNegocio instance = new facadeNegocio();
        instance.agregarSolicitudTraslado(fecha, IDEmpresa, detalles);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of obtenerListaResiduos method, of class facadeNegocio.
     */
    @Test
    public void testObtenerListaResiduos() {
        System.out.println("obtenerListaResiduos");
        facadeNegocio instance = new facadeNegocio();
        List<Residuo> expResult = null;
        List<Residuo> result = instance.obtenerListaResiduos();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of obtenerListaResiduosEmpresa method, of class facadeNegocio.
     */
    @Test
    public void testObtenerListaResiduosEmpresa() {
        System.out.println("obtenerListaResiduosEmpresa");
        EmpresaProductora empresa = null;
        facadeNegocio instance = new facadeNegocio();
        List<Residuo> expResult = null;
        List<Residuo> result = instance.obtenerListaResiduosEmpresa(empresa);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of obtenerListaElementosQuimicos method, of class facadeNegocio.
     */
    @Test
    public void testObtenerListaElementosQuimicos() {
        System.out.println("obtenerListaElementosQuimicos");
        facadeNegocio instance = new facadeNegocio();
        List<ElementoQuimico> expResult = null;
        List<ElementoQuimico> result = instance.obtenerListaElementosQuimicos();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of obtenerListaTraslados method, of class facadeNegocio.
     */
    @Test
    public void testObtenerListaTraslados() {
        System.out.println("obtenerListaTraslados");
        facadeNegocio instance = new facadeNegocio();
        List<Traslado> expResult = null;
        List<Traslado> result = instance.obtenerListaTraslados();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of obtenerListaSolicitudesNoAtendidas method, of class facadeNegocio.
     */
    @Test
    public void testObtenerListaSolicitudesNoAtendidas() {
        System.out.println("obtenerListaSolicitudesNoAtendidas");
        facadeNegocio instance = new facadeNegocio();
        List<Solicitud> expResult = null;
        List<Solicitud> result = instance.obtenerListaSolicitudesNoAtendidas();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of obtenerEmpresaProductora method, of class facadeNegocio.
     */
    @Test
    public void testObtenerEmpresaProductora() {
        System.out.println("obtenerEmpresaProductora");
        String identificador = "";
        facadeNegocio instance = new facadeNegocio();
        EmpresaProductora expResult = null;
        EmpresaProductora result = instance.obtenerEmpresaProductora(identificador);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of obtenerResiduo method, of class facadeNegocio.
     */
    @Test
    public void testObtenerResiduo() {
        System.out.println("obtenerResiduo");
        String identificador = "";
        facadeNegocio instance = new facadeNegocio();
        Residuo expResult = null;
        Residuo result = instance.obtenerResiduo(identificador);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of obtenerListaEmpresasTransporte method, of class facadeNegocio.
     */
    @Test
    public void testObtenerListaEmpresasTransporte() {
        System.out.println("obtenerListaEmpresasTransporte");
        facadeNegocio instance = new facadeNegocio();
        List<EmpresaTransporte> expResult = null;
        List<EmpresaTransporte> result = instance.obtenerListaEmpresasTransporte();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of obtenerSolicitud method, of class facadeNegocio.
     */
    @Test
    public void testObtenerSolicitud() {
        System.out.println("obtenerSolicitud");
        String identificador = "";
        facadeNegocio instance = new facadeNegocio();
        Solicitud expResult = null;
        Solicitud result = instance.obtenerSolicitud(identificador);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of agregarAsignacion method, of class facadeNegocio.
     */
    @Test
    public void testAgregarAsignacion() {
        System.out.println("agregarAsignacion");
        int solicitud = 0;
        String RFC = "";
        String IDResiduo = "";
        float cantidadReparto = 0.0F;
        String medida = "";
        facadeNegocio instance = new facadeNegocio();
        instance.agregarAsignacion(solicitud, RFC, IDResiduo, cantidadReparto, medida);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of obtenerAsignacionesEmpresa method, of class facadeNegocio.
     */
    @Test
    public void testObtenerAsignacionesEmpresa() {
        System.out.println("obtenerAsignacionesEmpresa");
        String identificador = "";
        facadeNegocio instance = new facadeNegocio();
        List<Asignacion> expResult = null;
        List<Asignacion> result = instance.obtenerAsignacionesEmpresa(identificador);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of obtenerEmpresaTransportadora method, of class facadeNegocio.
     */
    @Test
    public void testObtenerEmpresaTransportadora() {
        System.out.println("obtenerEmpresaTransportadora");
        String identificador = "";
        facadeNegocio instance = new facadeNegocio();
        EmpresaTransporte expResult = null;
        EmpresaTransporte result = instance.obtenerEmpresaTransportadora(identificador);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of obtenerVehiculosEmpresa method, of class facadeNegocio.
     */
    @Test
    public void testObtenerVehiculosEmpresa() {
        System.out.println("obtenerVehiculosEmpresa");
        String identificador = "";
        facadeNegocio instance = new facadeNegocio();
        List<Vehiculo> expResult = null;
        List<Vehiculo> result = instance.obtenerVehiculosEmpresa(identificador);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of registrarTraslado method, of class facadeNegocio.
     */
    @Test
    public void testRegistrarTraslado() {
        System.out.println("registrarTraslado");
        int IDAsignacion = 0;
        String fechaTermino = "";
        String tratamiento = "";
        List<Vehiculo> vehiculos = null;
        float costo = 0.0F;
        String EmpresaT = "";
        float kilometros = 0.0F;
        facadeNegocio instance = new facadeNegocio();
        instance.registrarTraslado(IDAsignacion, fechaTermino, tratamiento, vehiculos, costo, EmpresaT, kilometros);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
